# Bhumika Mobiles Android App

Proper Android Gradle project for Bhumika Mobiles.

- Location: Kathmandu, Nepal
- Phone: 9819962242
- Package: com.bhumikamobiles.app

## Build
Open in Android Studio and choose Build > Build APK(s).

## Phone/cloud build
Push this folder to GitHub, open Actions, select **Build Bhumika Mobiles APK**, and click **Run workflow**. The generated APK is uploaded as an artifact.
