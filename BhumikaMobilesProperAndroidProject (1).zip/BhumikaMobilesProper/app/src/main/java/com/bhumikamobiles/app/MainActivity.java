package com.bhumikamobiles.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    int blue = Color.rgb(13,71,161);
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView text(String s, float size, int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(dp(16),dp(10),dp(16),dp(10)); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    @Override public void onCreate(Bundle b){ super.onCreate(b); build(); }
    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(245,247,250));
        TextView head=text("BHUMIKA MOBILES",24,Color.WHITE); head.setGravity(Gravity.CENTER); head.setTypeface(null,1); head.setBackgroundColor(blue); head.setPadding(0,dp(20),0,dp(20)); root.addView(head,new LinearLayout.LayoutParams(-1,dp(76)));
        ScrollView scroll=new ScrollView(this); LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(12),dp(12),dp(12),dp(20));
        TextView welcome=text("Your Mobile Shop in Kathmandu\nMobiles • Accessories • Repair",22,Color.DKGRAY); welcome.setGravity(Gravity.CENTER); welcome.setTypeface(null,1); body.addView(welcome);
        addSection(body,"📱 Mobile Phones","Latest smartphones and popular models\nContact us for current prices and availability.");
        addSection(body,"🎧 Accessories","Chargers • Cables • Tempered Glass • Covers\nTWS • Power Banks • Speakers • Holders");
        addSection(body,"🔧 Repair Services","Display replacement • Battery replacement\nSoftware service • Charging problems • General repair");
        Button call=button("📞  Call 9819962242"); call.setOnClickListener(v->{ startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:9819962242"))); }); body.addView(call,new LinearLayout.LayoutParams(-1,dp(54)));
        Button location=button("📍  Kathmandu, Nepal"); location.setOnClickListener(v->{ startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q=Kathmandu,Nepal"))); }); body.addView(location,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView footer=text("Bhumika Mobiles\nThank you for visiting us!",15,Color.GRAY); footer.setGravity(Gravity.CENTER); body.addView(footer);
        scroll.addView(body); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    void addSection(LinearLayout body,String title,String desc){ TextView t=text(title,19,blue); t.setTypeface(null,1); body.addView(t); TextView d=text(desc,15,Color.DKGRAY); d.setBackgroundColor(Color.WHITE); body.addView(d,new LinearLayout.LayoutParams(-1,dp(88))); Space sp=new Space(this); body.addView(sp,new LinearLayout.LayoutParams(1,dp(8))); }
}
